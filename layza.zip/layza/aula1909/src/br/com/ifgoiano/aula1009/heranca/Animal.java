package br.com.ifgoiano.aula1009.heranca;


public class Animal {
    String nome;
    
    public void comer(){
        System.out.print("O animal esta comendo");
    }
    
}
