package br.com.ifgoiano.aula1009.heranca;

/**
 *
 * @author aluno
 */
public class Cachorro extends Animal {
    public void latir (){
        System.out.print("O cachorro esta latindo");
    }
    
}
