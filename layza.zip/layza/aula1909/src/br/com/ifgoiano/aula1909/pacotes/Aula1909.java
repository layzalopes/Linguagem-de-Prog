package br.com.ifgoiano.aula1909.pacotes;

import br.com.ifgoiano.aula1909.novopacote.NovaClasse;
        
public class Aula1909 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
