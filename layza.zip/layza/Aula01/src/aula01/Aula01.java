package aula01;

import java.util.Scanner;

public class Aula01 {
    
    public static void somar(int num1, int num2){
        System.out.println("O resultado da soma é: " + (num1 + num2));

    }
    
    public static int somarRetornando(int num1, int num2){
        return num1 + num2;
    }
    
    public static void subtrair(int num1, int num2){
        System.out.println("O resultado da subtração é: " + (num1 - num2));

    }
    public static int subtrairRetornando(int num1, int num2){
        return num1 - num2;
    }
    
     public static void multiplicar(int num1, int num2){
        System.out.println("O resultado da multiplicação é: " + (num1 * num2));

    }
     public static int multiplicarRetornando(int num1, int num2){
        return num1 * num2;
    }
     
     public static void dividir(int num1, int num2){
        System.out.println("O resultado da divisão é: " + (num1 / num2));

    }
     public static int dividirRetornando(int num1, int num2){
        return num1 / num2;
    }
     

    public static void main(String[] args) {
        
        int numero1, numero2, opcao;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("1- Somar");
        System.out.println("2- Subtrair");
        System.out.println("3- Multiplicar");
        System.out.println("4- Dividir");
        
        opcao = sc.nextInt();
        
        if (opcao ==0 || opcao > 4) {
            System.out.println("Escolha uma opção válida!");
            System.exit(0);
        }
        
        System.out.println("Digite o primeiro número");
        numero1 = sc.nextInt();
        System.out.println("Digite o segundo número");
        numero2 = sc.nextInt();
        
        OperacoesMatematicas operacoes = new OperacoesMatematicas(numero1, numero2);
        
        switch (opcao) {
           case 1 -> 
            //somar(numero1, numero2);
            System.out.println("O valor da soma é " +somarRetornando(numero1, numero2));

            case 2 -> 
            //subtrair(numero1, numero2);
            System.out.println("O valor da subtração é " +subtrairRetornando(numero1, numero2));

            case 3 -> 
            //multiplicar(numero1, numero2);
            System.out.println("O valor da multiplicação é " +multiplicarRetornando(numero1, numero2));

            case 4 -> 
            //dividir(numero1, numero2);
            System.out.println("O valor da divisão é " +dividirRetornando(numero1, numero2));


    }




    }
    
}
