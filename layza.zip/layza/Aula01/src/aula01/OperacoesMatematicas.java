
package aula01;

public class OperacoesMatematicas {
    
    private final int numero1, numero2; {
        numero1 = num1;
        numero2 = num2;
}
    
    public void somar(int num1, int num2){
        System.out.println("O resultado da soma é: " + (num1 + num2));

    }
    public void subtrair(int num1, int num2){
        System.out.println("O resultado da subtração é: " + (num1 - num2));

    }
    public void multiplicar(int num1, int num2){
        System.out.println("O resultado da multiplicação é: " + (num1 * num2));

    }
    public void dividir(int num1, int num2){
        System.out.println("O resultado da divisão é: " + (num1 / num2));

    }
    
}
